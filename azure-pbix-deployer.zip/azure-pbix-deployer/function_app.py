import json
import logging
import os
from typing import Any, Dict, Optional, Tuple
from urllib.parse import quote

import azure.functions as func
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

app = func.FunctionApp(http_auth_level=func.AuthLevel.FUNCTION)

GRAPH_SCOPE = "https://graph.microsoft.com/.default"
POWER_BI_SCOPE = "https://analysis.windows.net/powerbi/api/.default"
GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0"
POWER_BI_BASE_URL = "https://api.powerbi.com/v1.0/myorg"
REQUEST_TIMEOUT = 120
DOWNLOAD_TIMEOUT = 600
VALID_DEPLOYMENTS = {"dev", "vprod", "prod"}


def get_env(name: str, required: bool = True, default: Optional[str] = None) -> str:
    value = os.getenv(name, default)
    if required and not value:
        raise ValueError(f"Missing required environment variable: {name}")
    return value or ""


def build_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=3,
        connect=3,
        read=3,
        backoff_factor=1,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET", "POST"],
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session


SESSION = build_session()


class AppError(Exception):
    def __init__(self, message: str, status_code: int = 400, details: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.details = details or {}


def get_access_token(scope: str) -> str:
    tenant_id = get_env("AZURE_TENANT_ID")
    client_id = get_env("AZURE_CLIENT_ID")
    client_secret = get_env("AZURE_CLIENT_SECRET")

    token_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    payload = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret,
        "scope": scope,
    }

    response = SESSION.post(token_url, data=payload, timeout=REQUEST_TIMEOUT)
    if not response.ok:
        raise AppError(
            "Failed to acquire access token",
            status_code=500,
            details={
                "scope": scope,
                "status_code": response.status_code,
                "response": safe_json_or_text(response),
            },
        )

    data = response.json()
    token = data.get("access_token")
    if not token:
        raise AppError("Token response did not contain access_token", status_code=500, details=data)

    return token


def safe_json_or_text(response: requests.Response) -> Any:
    try:
        return response.json()
    except Exception:
        return response.text


def graph_headers(token: str) -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }


def power_bi_headers(token: str) -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {token}",
    }


def normalize_deployment(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    normalized = str(value).strip().lower()
    return normalized if normalized else None


def resolve_workspace_name(ha: str, deployment: str) -> str:
    ha_clean = ha.strip().upper()
    deployment_clean = deployment.strip().lower()

    if deployment_clean == "dev":
        return f"PP-{ha_clean}-N-BASIS"
    if deployment_clean == "vprod":
        return f"PP-{ha_clean}-N-VPROD"
    if deployment_clean == "prod":
        return f"PP-{ha_clean}-N-PROD"

    raise AppError(f"Unsupported deployment value: {deployment}", status_code=400)


def build_skip_response(
    file_reference: str,
    file_name: Optional[str],
    ha: Optional[str],
    deployment: Optional[str],
    target_workspace: Optional[str],
    message: str,
) -> Dict[str, Any]:
    return {
        "status": "skipped",
        "file_name": file_name,
        "file_reference": file_reference,
        "ha": ha,
        "deployment": deployment,
        "target_workspace": target_workspace,
        "message": message,
    }


def make_json_response(body: Dict[str, Any], status_code: int = 200) -> func.HttpResponse:
    return func.HttpResponse(
        body=json.dumps(body, ensure_ascii=False),
        status_code=status_code,
        mimetype="application/json",
    )


def resolve_request_payload(req: func.HttpRequest) -> Dict[str, Any]:
    try:
        body = req.get_json()
        if isinstance(body, dict):
            return body
    except ValueError:
        pass
    return {}


def resolve_file_reference(payload: Dict[str, Any]) -> Tuple[str, str]:
    if payload.get("drive_item_id"):
        return "drive_item_id", str(payload["drive_item_id"])
    if payload.get("sharepoint_item_id"):
        return "sharepoint_item_id", str(payload["sharepoint_item_id"])
    if payload.get("file_path"):
        return "file_path", str(payload["file_path"])
    raise AppError(
        "Request body must contain one of: drive_item_id, sharepoint_item_id, file_path",
        status_code=400,
    )


def get_site_and_drive_config() -> Dict[str, str]:
    return {
        "site_id": get_env("SHAREPOINT_SITE_ID"),
        "drive_id": get_env("SHAREPOINT_DRIVE_ID"),
    }


def get_drive_item(graph_token: str, ref_type: str, ref_value: str) -> Dict[str, Any]:
    config = get_site_and_drive_config()
    site_id = config["site_id"]
    drive_id = config["drive_id"]

    if ref_type in {"drive_item_id", "sharepoint_item_id"}:
        url = (
            f"{GRAPH_BASE_URL}/sites/{site_id}/drives/{drive_id}/items/{quote(ref_value)}"
            f"?$expand=listItem($expand=fields)"
        )
    elif ref_type == "file_path":
        encoded_path = quote(ref_value.strip("/"))
        url = (
            f"{GRAPH_BASE_URL}/sites/{site_id}/drives/{drive_id}/root:/{encoded_path}:"
            f"?$expand=listItem($expand=fields)"
        )
    else:
        raise AppError(f"Unsupported file reference type: {ref_type}", status_code=400)

    response = SESSION.get(url, headers=graph_headers(graph_token), timeout=REQUEST_TIMEOUT)
    if response.status_code == 404:
        raise AppError("SharePoint file was not found", status_code=404, details={"file_reference": ref_value})
    if not response.ok:
        raise AppError(
            "Failed to read file metadata from Microsoft Graph",
            status_code=502,
            details={"status_code": response.status_code, "response": safe_json_or_text(response)},
        )
    return response.json()


def extract_sharepoint_fields(drive_item: Dict[str, Any]) -> Dict[str, Any]:
    list_item = drive_item.get("listItem") or {}
    fields = list_item.get("fields") or {}
    return fields


def is_pbix_file(file_name: Optional[str]) -> bool:
    return bool(file_name and file_name.lower().endswith(".pbix"))


def download_pbix(graph_token: str, drive_item_id: str) -> bytes:
    config = get_site_and_drive_config()
    site_id = config["site_id"]
    drive_id = config["drive_id"]

    url = f"{GRAPH_BASE_URL}/sites/{site_id}/drives/{drive_id}/items/{quote(drive_item_id)}/content"
    response = SESSION.get(url, headers=graph_headers(graph_token), timeout=DOWNLOAD_TIMEOUT, stream=True)
    if not response.ok:
        raise AppError(
            "Failed to download .pbix file from SharePoint",
            status_code=502,
            details={"status_code": response.status_code, "response": safe_json_or_text(response)},
        )

    return response.content


def find_workspace_id(power_bi_token: str, workspace_name: str) -> Optional[str]:
    url = f"{POWER_BI_BASE_URL}/groups"
    response = SESSION.get(url, headers=power_bi_headers(power_bi_token), timeout=REQUEST_TIMEOUT)
    if not response.ok:
        raise AppError(
            "Failed to query Power BI workspaces",
            status_code=502,
            details={"status_code": response.status_code, "response": safe_json_or_text(response)},
        )

    groups = response.json().get("value", [])
    for group in groups:
        if group.get("name") == workspace_name:
            return group.get("id")
    return None


def import_pbix_to_workspace(
    power_bi_token: str,
    workspace_id: str,
    file_name: str,
    file_bytes: bytes,
) -> Dict[str, Any]:
    # Best-effort overwrite strategy:
    # Power BI Imports API supports multipart/form-data import with nameConflict=Overwrite.
    # In practice, overwrite works for supported import scenarios, but some PBIX/content combinations
    # can still fail because of Power BI service limitations (for example unsupported labels or import constraints).
    url = (
        f"{POWER_BI_BASE_URL}/groups/{workspace_id}/imports"
        f"?datasetDisplayName={quote(file_name)}&nameConflict=Overwrite"
    )

    files = {
        "file": (
            file_name,
            file_bytes,
            "application/octet-stream",
        )
    }

    response = SESSION.post(
        url,
        headers=power_bi_headers(power_bi_token),
        files=files,
        timeout=DOWNLOAD_TIMEOUT,
    )

    if not response.ok:
        raise AppError(
            "Failed to import .pbix into Power BI workspace",
            status_code=502,
            details={"status_code": response.status_code, "response": safe_json_or_text(response)},
        )

    return response.json()


@app.route(route="deploy-pbix", methods=["POST"])
def deploy_pbix(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Received PBIX deployment request")

    try:
        payload = resolve_request_payload(req)
        ref_type, ref_value = resolve_file_reference(payload)

        graph_token = get_access_token(GRAPH_SCOPE)
        power_bi_token = get_access_token(POWER_BI_SCOPE)

        drive_item = get_drive_item(graph_token, ref_type, ref_value)
        fields = extract_sharepoint_fields(drive_item)

        file_name = drive_item.get("name")
        drive_item_id = drive_item.get("id")
        file_reference_out = ref_value

        if not is_pbix_file(file_name):
            message = "File is not a .pbix file. Skipping deployment."
            logging.warning(message)
            return make_json_response(
                build_skip_response(file_reference_out, file_name, None, None, None, message),
                status_code=200,
            )

        ha = fields.get("HA")
        raw_deployment = fields.get("Deployment")
        deployment = normalize_deployment(raw_deployment)

        if not ha:
            message = "SharePoint metadata field 'HA' is missing. Skipping deployment."
            logging.warning(message)
            return make_json_response(
                build_skip_response(file_reference_out, file_name, None, deployment, None, message),
                status_code=200,
            )

        if not deployment:
            message = "SharePoint metadata field 'Deployment' is missing. Skipping deployment."
            logging.warning(message)
            return make_json_response(
                build_skip_response(file_reference_out, file_name, ha, None, None, message),
                status_code=200,
            )

        if deployment not in VALID_DEPLOYMENTS:
            message = f"SharePoint metadata field 'Deployment' has invalid value '{raw_deployment}'. Skipping deployment."
            logging.warning(message)
            return make_json_response(
                build_skip_response(file_reference_out, file_name, ha, deployment, None, message),
                status_code=200,
            )

        target_workspace = resolve_workspace_name(ha, deployment)
        workspace_id = find_workspace_id(power_bi_token, target_workspace)

        if not workspace_id:
            message = f"Target Power BI workspace '{target_workspace}' was not found. Skipping deployment."
            logging.warning(message)
            return make_json_response(
                build_skip_response(file_reference_out, file_name, ha, deployment, target_workspace, message),
                status_code=200,
            )

        if not drive_item_id:
            raise AppError("Drive item ID is missing in Graph response", status_code=500)

        pbix_bytes = download_pbix(graph_token, drive_item_id)
        import_result = import_pbix_to_workspace(power_bi_token, workspace_id, file_name, pbix_bytes)

        message = f"PBIX imported successfully into workspace '{target_workspace}'."
        logging.info(
            "Deployment successful | file_name=%s | drive_item_id=%s | ha=%s | deployment=%s | workspace=%s",
            file_name,
            drive_item_id,
            ha,
            deployment,
            target_workspace,
        )

        response_body = {
            "status": "success",
            "file_name": file_name,
            "file_reference": file_reference_out,
            "sharepoint_item_id": fields.get("id") or drive_item.get("sharepointIds", {}).get("listItemId"),
            "drive_item_id": drive_item_id,
            "ha": ha,
            "deployment": deployment,
            "target_workspace": target_workspace,
            "workspace_id": workspace_id,
            "message": message,
            "power_bi_import_id": import_result.get("id"),
            "power_bi_import_state": import_result.get("importState"),
        }
        return make_json_response(response_body, status_code=200)

    except AppError as exc:
        logging.exception("Handled application error: %s", exc.message)
        response_body = {
            "status": "error",
            "file_name": None,
            "file_reference": None,
            "ha": None,
            "deployment": None,
            "target_workspace": None,
            "message": exc.message,
            "details": exc.details,
        }
        return make_json_response(response_body, status_code=exc.status_code)
    except Exception as exc:
        logging.exception("Unhandled error during PBIX deployment")
        response_body = {
            "status": "error",
            "file_name": None,
            "file_reference": None,
            "ha": None,
            "deployment": None,
            "target_workspace": None,
            "message": "Unhandled server error",
            "details": {"exception": str(exc)},
        }
        return make_json_response(response_body, status_code=500)
