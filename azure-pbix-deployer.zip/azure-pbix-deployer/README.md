# Azure Function: SharePoint PBIX Deployer

HTTP-triggered Azure Function (Python, v2 model) that reads one SharePoint file per call, validates SharePoint metadata (`HA`, `Deployment`), derives the target Power BI workspace name, downloads the `.pbix`, and imports it into the matching Power BI workspace.

## Route

`POST /api/deploy-pbix`

## Accepted request body

```json
{
  "drive_item_id": "01ABCDEF..."
}
```

Alternative request body shapes:

```json
{
  "sharepoint_item_id": "1234"
}
```

```json
{
  "file_path": "Shared Documents/Power BI/Sales Report.pbix"
}
```

## Required app registration permissions

### Microsoft Graph (application permissions)
- `Sites.Read.All` or a narrower site-specific setup if you use resource-specific consent
- `Files.Read.All` can also be relevant depending on your tenant setup

### Power BI
- Service principal access must be enabled in the Power BI tenant.
- The service principal must have access to the target workspaces.
- Use permissions sufficient for reading workspaces and importing content.

## Notes

- `Deployment` must be exactly one of `dev`, `vprod`, `prod`.
- Workspace name format is hardcoded:
  - `PP-{HA}-N-BASIS`
  - `PP-{HA}-N-VPROD`
  - `PP-{HA}-N-PROD`
- Import uses `nameConflict=Overwrite` as the best available overwrite strategy.
